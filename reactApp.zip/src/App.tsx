import ListGroup from "./ListGroup";

function App() {

  return (
    <>
      <div>
        <ListGroup/>
      </div>
    </>
  );
}

export default App

function ListGroup(){
    const items = [['Ryu ', 'Ken ', 'Sagat ', 'Chun-Li'],['Guile ', 'Vega ', 'Balrog ', 'M Bison'], ['Blanka ', 'E Honda ', 'Dhalsim ', 'Zangief '], ['Cammy ', 'Fei Long ', 'T Hawk ', 'Dee Jay']]

    if (items.length === 0)
        return<p>Void</p>
    return   (
        <>
            <h1>Select Fighter</h1>
            <ul className="list-group">
                {items.map((item) => (<li>{item}</li>))}
            </ul>
        </>
  );
}

export default ListGroup;
function Message(){
    const name = '';

    if (name)
        return <h1>Konnichiwa, {name} Taichou!</h1>;

    return <h1>In the desert... You can't remember your name~</h1>
}

export default Message;


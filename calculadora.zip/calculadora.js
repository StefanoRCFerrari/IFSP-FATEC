const display = document.getElementById('display');
const containerBotoes = document.querySelector('.buttons');

function manipularEntrada(valor){
    const textoAtual = display.textContent;

    if (valor === 'C'){
        display.textContent = '0';
    }
    else if (valor === '⌫'){
        if (textoAtual.length === 1 || textoAtual === 'Erro'){
            display.textContent = '0';
        }
        else{
            display.textContent = textoAtual.slice(0, -1)
        }
    }
    else if (valor === '='){
        try {
            let result = eval(textoAtual.replace('Erro', '0'));
            display.textContent = result;
        } catch(error) {
            display.textContent = 'Erro';
        }
    }
    else if (textoAtual === '0' && valor != '.' || textoAtual === 'Erro') {
        display.textContent = valor;
    }
    else {
        display.textContent += valor;
    }
}

containerBotoes.addEventListener('click',(event) => {
    if(!event.target.matches('button')){
        return;
    }
    const valor = event.target.dataset.valor;
    manipularEntrada(valor);
}
);

window.addEventListener('keydown', (event) => {
    const key = event.key;
    let value = null;

    if (key >= 0 && key <= 9){
        value = key;
    } else if (key === '+' || key === '-' || key === '/' || key === '*') {
        event.preventDefault();
        value = key;
    } else if (key === '.' || key === ',') {
        value = '.';
    } else if (key === 'Enter' || key === '=') {
        event.preventDefault();
        value = '=';
    } else if (key === 'Escape') {
        value = 'C';
    } else if (key === 'Backspace') {
        value = 'Backspace';
    }
})
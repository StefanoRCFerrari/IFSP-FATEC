let prompt = require("prompt-sync")();

function calcularJuros(){

    let total = Number(prompt("Valor total: R$"));
    let entrada = Number(prompt("Entrada: R$"));
    let restante = total - entrada;
    let juros = Number(prompt("Juros ao mês (em %): "));
    juros = juros/100
    let periodo = Number(prompt("Quantidade de parcelas: "));
    return restante*(juros*(1+juros)**periodo)/((1+juros)**periodo-1)
}

resultado = calcularJuros();
console.log(`Valor das Mensalidades: ${resultado}`);
let prompt = require("prompt-sync")();

let n1 = Number(prompt("Insira o primeiro número: "));
let n2 = Number(prompt("Insira o segundo número: "));

let operacao = prompt("Qual a operação que deseja executar?");

function calcular(n1, n2, operacao){

    if (operacao.toUpperCase() === "SOMA" || operacao === "+")
        return n1+n2;
    if (operacao.toUpperCase() === "SUBTRAÇÃO" || operacao === "-")
        return n1-n2;
    if (operacao.toUpperCase() === "MULTIPLICAÇÃO" || operacao === "*")
        return n1*n2;
    if (operacao.toUpperCase() === "DIVISÃO" || operacao === "/")
        return n1/n2;
    }

resultado = calcular(n1, n2, operacao);
console.log(`Resultado: ${resultado}`);
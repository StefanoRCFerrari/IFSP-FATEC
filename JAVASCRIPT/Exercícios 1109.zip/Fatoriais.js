let prompt = require("prompt-sync")();

function fatorial(num){
    if (num === 0)
        return 1;
    else
        return num*=fatorial(num-1);
}
let numero = Number(prompt("Fatorial de: "));
resultado = fatorial(numero);
console.log(`Seu fatorial é: ${resultado}`);

/*
function fatorial(num){
    let fatorial = 1   ; 
        while (num > 1){
            fatorial *= num;
            num--;
            }
    return fatorial;
}

function fatorial(num){
    let fatorial = 1;
        for (cont = 1; cont <= num; cont++){
            fatorial *= cont;
            num--;
            }
        return fatorial;  
}

Poucas diferenças reais, apenas a necessidade de cuidado com as variáveis que controlam até quando
multiplicar e tomar cuidado para que não caia no erro de multiplicar por zero.*/
let a, b, c;
let prompt = require("prompt-sync")();

a = Number(prompt("Insira o valor de A: "));
b = Number(prompt("Insira o valor de B: "));
c = Number(prompt("Insira o valor de C: "));

let delta = (b*b - 4*a*c);
if(delta < 0){
    console.log("Não possui raízes reais.")
} else if (delta == 0) {
    let x = -b/(2*a);
    console.log("O sistema possui uma raíz real de multiplicidade dois.");
    console.log(` delta = 0          x = ${x}`);
} else {
    let x1 = (-b -(delta**(1/2)))/(2*a)
    let x2 = (-b +(delta**(1/2)))/(2*a)
    console.log("O sistema possui duas raízes reais:")
    console.log(`x1 = ${x1}`)
    console.log(`x2 = ${x2}`)
}


let fibo1 = 1
let fibo2 = 1
let proxfibo = fibo1 + fibo2

console.log(`${fibo1}`)
console.log(`${fibo2}`)

impares = []
pares = []
impares += (fibo1 + ' ')
impares += (fibo2 + ' ')


for (let count = 1; count <= 20; count++)
{
    console.log(`${proxfibo}`)
    fibo1 = fibo2
    fibo2 = proxfibo
    proxfibo = fibo1 + fibo2
    if (proxfibo%2==0)
        pares += (proxfibo + ' ')
    else
        impares += (proxfibo + ' ')
}

console.log(`Pares: ${pares}`)
console.log(`Ímpares: ${impares}`)

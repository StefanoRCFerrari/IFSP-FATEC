let num1 = Math.round(Math.random()*5)+1
//Pega um float entre 0 e 1, faz x5, o que deixa entre 0 e 4.999999999 e arredondando e somando 1, fica entre 1 e 6
let num2 = Math.floor(Math.random()*7)
//Pega um flota entre 0 e 1, faz x7 e arredonda para baixo, ficando entre 0 e 6

for (cont = 0; cont < 100; cont++)
{
    num3 = Math.random()
    if (cont==0)
    {
        var maior = num3
        var menor = num3
    }
    else if (num3 > maior)
    {
        maior = num3
    }
    else if (num3 < menor)
    {
        menor = num3
    }
}
    console.log(`Maior = ${maior}          Menor = ${menor}`)

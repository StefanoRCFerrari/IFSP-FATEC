let prompt = require("prompt-sync")();
var num = prompt("Insira um número: ")
var divs = 0

for (cont = 2; cont < num; cont++)
{
    if (num%cont==0)
        divs++
}

if (divs > 0)
    console.log("Não é primo")
else
    console.log("É primo")
let prompt = require("prompt-sync")();

var ref = prompt("Peso consumido por refeição: ")
var pac = prompt("Peso em cada pacote: ")
var total = parseInt(pac/ref)
console.log(`É possível servir ${total} refeições.`)

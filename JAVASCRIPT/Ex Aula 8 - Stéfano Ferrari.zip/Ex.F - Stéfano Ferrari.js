let prompt = require("prompt-sync")();

console.log("Informe 3 números inteiros distintos entre 1 e 6 que você acredita que estejam em minha lista e lhe direi caso acerte 2 ou mais deles")
resp = "S"

while (resp === "S")
{
    let acerto = 0
    let lista = []

    while (lista.length <3)
    {
        randnum = parseInt(Math.floor(Math.random()*6)+1)
        if (!lista.includes(randnum))
            lista.push(randnum)
    }

    let num1 = parseInt(prompt("Qual seu primeiro palpite?"))
    while (num1 > 6 || num1 < 1 || isNaN(num1))
       num1 = parseInt(prompt("Input fora das regras... Qual seu primeiro palpite?"))
    
    let num2 = parseInt(prompt("Qual seu segundo palpite?"))
    while (num1 === num2 || num2 > 6 || num2 < 1 || isNaN(num2))
        num2 = parseInt(prompt("Input fora das regras... Qual seu segundo palpite?"))

    let num3 = parseInt(prompt("Qual seu terceiro palpite?"))
    while (num1 === num3 || num2 === num3 || num3 > 6 || num3 < 1 || isNaN(num3))
        num3 = parseInt(prompt("Input fora das regras... Qual seu terceiro palpite?"))
    
    
    
    if (lista.includes(num1))
        acerto++
    if (lista.includes(num2))
        acerto++
    if (lista.includes(num3))
        acerto++

    console.log(`Meus números: ${lista}`)
    console.log(`Seus palpites: ${num1} ${num2} ${num3}`)

    if (acerto >= 2)
        console.log("Parabéns! Acertou 2 ou mais!")
    else
        console.log("Não foi dessa vez...")

    resp = prompt("Deseja tentar novamente? Digite APENAS um S maiúsculo se quiser ou qualquer outra coisa para encerrar o jogo.")
}
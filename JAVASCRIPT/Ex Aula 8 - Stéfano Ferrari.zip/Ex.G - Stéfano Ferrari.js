let prompt = require("prompt-sync")();

let capital = Number(prompt("Informe o capital inicialmente investido (em reais): "))
    while(isNaN(capital))
        capital = Number(prompt("Input Inválido. Informe o capital inicialmente investido (em reais): "))

let taxaJuros = Number(prompt("Informe a taxa de juros mensal no formato 0.0 (0%) até 1.0 (100%): "))
    while(isNaN(taxaJuros) || taxaJuros < 0 || taxaJuros > 1)
        taxaJuros = Number(prompt("Input Inválido. Informe a taxa de juros mensal no formato 0.0 (0%) até 1.0 (100%): "))

let meses = Number(prompt("Informe o prazo (em meses) para o pagamento deste empréstimo: "))
    while(isNaN(meses))
        meses = Number(prompt("Input Inválido. Informe o prazo (em meses) para o pagamento deste empréstimo: "))

let mensalidade = (capital * taxaJuros) / (1 - Math.pow((1 + taxaJuros), -meses))

let format = mensalidade.toLocaleString('pt-br',{style: 'currency', currency: 'BRL'})

console.log(`A mensalidade em ${meses} meses, juro mensal de ${taxaJuros} é ${format}`)